import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Heritage.css'; // Assuming you have a separate CSS file for custom styles
import mainImg1 from '../../../Assets/AboutUs/heritage/heritage01.png'
import mainImg2 from '../../../Assets/AboutUs/heritage/heritage02.png'
import mainImg3 from '../../../Assets/AboutUs/heritage/heritage03.png'
import year1944 from '../../../Assets/AboutUs/heritage/1944-n.png'
import year1948 from '../../../Assets/AboutUs/heritage/1948-n.png'
import year1953 from '../../../Assets/AboutUs/heritage/1953-n.png'
import year1968 from '../../../Assets/AboutUs/heritage/1968-n.png'
import year1976 from '../../../Assets/AboutUs/heritage/1976-n.png'
import year1995 from '../../../Assets/AboutUs/heritage/1995-n.png'
import year1999 from '../../../Assets/AboutUs/heritage/1999-n.png'
import year2002 from '../../../Assets/AboutUs/heritage/2002-n.png'
import year2011 from '../../../Assets/AboutUs/heritage/2011-n.png'
import year2013 from '../../../Assets/AboutUs/heritage/2013-n.png'
import year2016 from '../../../Assets/AboutUs/heritage/2016-n.png'
import year20241 from '../../../Assets/AboutUs/heritage/2024-n.png'
import year20242 from '../../../Assets/AboutUs/heritage/2024-n.png'
// import DemoTime from './DemoTime'
import { VerticalTimeline, VerticalTimelineElement } from 'react-vertical-timeline-component';
import 'react-vertical-timeline-component/style.min.css';
// import VerticalTimeline from './VerticalTimeline';
const timeline = [
    {
        id: 1,
        date: '1944',
        image: year1944,
        desc: 'The Company incorporated as "Jagatjit Distillery & Allied Industries Ltd.” In Kapurthala under the patronage of its Maharaja, H.E Sardar Jagatjit Singh.',
    },
    {
        id: 2,
        date: '1948',
        image: year1948,
        desc: 'The first Distillery plant was set up in Kapurthala.',
    },
    {
        id: 3,
        date: '1953',
        image: year1953,
        desc: 'Entered into an agreement with Schweppes Overseas Ltd. & Pepsi Cola Ltd. to set up bottling & soft drinks plant.',
    },
    {
        id: 4,
        date: '1968',
        image: year1968,
        desc: 'Hyderabad brewery Ltd. was bought over. A new health drink by the name of VIVA was launched.',
    },
    {
        id: 5,
        date: '1973',
        image: null,
        desc: 'Glass plant set up as a separate company  with the name of ‘Universal Glass Ltd’',
    },
    {
        id: 6,
        date: '1976',
        image: year1976,
        desc: 'MALTOVA - New Product Launch',
    },
    {
        id: 7,
        date: '1982',
        image: null,
        desc: 'Maltova & Aristocrat Premium Malt Whisky awarded Gold Medal, by MONDE (World) selection held in London.',
    },
    {
        id: 8,
        date: '1985',
        image: null,
        desc: 'Aristocrat Premium Malt was launched.',
    },
    {
        id: 9,
        date: '1995',
        image: year1995,
        desc: "Hiram Walker launched- Teacher's Scotch Whisky.",
    },
    {
        id: 10,
        date: '1999',
        image: year1999,
        desc: 'Aristocrat Whisky, Bonnie  & Binnies entered the Millionaire Club.',
    },
    {
        id: 11,
        date: '2002',
        image: year2002,
        desc: 'AC Black and AC SEKC Whisky was launched.',
    },
    {
        id: 12,
        date: '2006',
        image: null,
        desc: 'ACP Whisky enters Millionaire Club',
    },
    {
        id: 13,
        date: '2010',
        image: null,
        desc: 'AC Black crosses Million mark.',
    },
    {
        id: 14,
        date: '2011',
        image: year2011,
        desc: 'IICE Vodka is launched.',
    },
    {
        id: 15,
        date: '2013',
        image: year2013,
        desc: 'IICE Vodka wins Gold at MONDE SELECTION QUALITY INSTITUTION Belgium.',
    },
    {
        id: 16,
        date: '2016',
        image: year2016,
        desc: 'Ms. Roshini Sanah Jaiswal won the ‘Entrepreneur of the year’ Award at Indspirit 2016 (The mega Alcobev Trade Event).IICE Vodka won the Gold Award for Standard Product of the Year at Indspirit 2016 (The mega Alcobev Trade Event).AC Black Whisky in Packaging category won the Gold award at Indspirit 2016 (The mega Alcobev Trade Event).',
    },
    {
        id: 17,
        date: '2020',
        image: null,
        desc: 'Introducing ACP Aristocrat HAND SANITIZER WITH 70% ALCOHOL and Humaste HAND SANITIZER WITH 70% ALCOHOL & Aloe-Vera.',
    },
    {
        id: 18,
        date: '2024',
        image: year20241,
        desc: 'Ms.Roshini Sanah Jaiswal has been honoured as the “Family Entrepreneur of the Year at The ET Entrepreneur Awards 2024”.',
    },
    {
        id: 19,
        date: '2024',
        image: year20242,
        desc: 'AC Black and Damn Good Scotch has won The Ambrosia Awards in the Product Category.',
    },

];

const TimeLine = () => {
    return (
        <div className="heritage-container">
            <div className="first-section">
            <div className="heritage-heading">
               <h1>Heritage</h1>
               </div>
               
            <div className="heritage-sec">
                <div className="container">
                <div className="row align-items-center heritage-item">
                        <div className="col-md-6">
                            <h2 className="heritage-number">01</h2>
                            <h3 className="heritage-title">Maharaja, Jagatjit Singh.</h3>
                            <p className="heritage-text">
                                Jagatjit Industries was founded in 1944 by the Late Mr. LP Jaiswal in the erstwhile state of Kapurthala,
                                under the patronage of its Maharaja, Jagatjit Singh. Jagatjit Chemical and Pharmaceutical Works and 
                                the Jagatjit Laboratories were established in 1946, and the distillery began operations in 1948.
                                The company then obtained a license for the annual manufacture of malt extract of 1800 tons, the 
                                largest in the country at the time, and started production in 1963.
                            </p>
                        </div>
                        <div className="col-md-6 ">
                            <img src={mainImg1} alt="Maharaja Jagatjit Singh" className="img-fluid" />
                        </div>
                    </div>
                    <div className="row align-items-center heritage-item">
                        <div className="col-md-6">
                        <img src={mainImg2} alt="Maharaja Jagatjit Singh" className="img-fuild" />
                        </div>
                        <div className="col-md-6">
                           
                            <h2 className="heritage-number">02</h2>
                            <h3 className="heritage-title">Maharaja, Jagatjit Singh.</h3>
                            <p className="heritage-text">
                                Jagatjit Industries was founded in 1944 by the Late Mr. LP Jaiswal in the erstwhile state of Kapurthala,
                                under the patronage of its Maharaja, Jagatjit Singh. Jagatjit Chemical and Pharmaceutical Works and 
                                the Jagatjit Laboratories were established in 1946, and the distillery began operations in 1948.
                                The company then obtained a license for the annual manufacture of malt extract of 1800 tons, the 
                                largest in the country at the time, and started production in 1963.
                            </p>
                        </div>
                    </div>
                    <div className="row align-items-center heritage-item">
                        <div className="col-md-6">
                            <h2 className="heritage-number">03</h2>
                            <h3 className="heritage-title">Maharaja, Jagatjit Singh.</h3>
                            <p className="heritage-text">
                                Jagatjit Industries was founded in 1944 by the Late Mr. LP Jaiswal in the erstwhile state of Kapurthala,
                                under the patronage of its Maharaja, Jagatjit Singh. Jagatjit Chemical and Pharmaceutical Works and 
                                the Jagatjit Laboratories were established in 1946, and the distillery began operations in 1948.
                                The company then obtained a license for the annual manufacture of malt extract of 1800 tons, the 
                                largest in the country at the time, and started production in 1963.
                            </p>
                        </div>
                        <div className="col-md-6 ">
                            <img src={mainImg3} alt="Maharaja Jagatjit Singh" className="img-fuild" />
                        </div>
                    </div>
                     <p className='global-p-2 text-align-center'>Jagatjit Industries Limited (JIL) is now one of world’s leaders in the premium drinks segment. We have the largest 
                     integrated distilleries manufacturing potable alcohol in Asia; and in India, we are the first to possess in-house capabilities for producing molasses and non-molasses based potable alcohol from fully automated distillation plants. JIL manufactures and markets alcoholic beverages, malt, malt extract, nutritious planned food, milk powder, ghee, and dairy products. We also manufacture malted milk foods. JIL’s guiding philosophy – ‘A Heritage of Quality’ – finds expression through all the company’s activities: quality in manufacturing, state-of-the-art-technology, and enduring relationships with employees, dealers and customers.</p>
                </div>
            </div>
            </div>
             

        

            <div style={{ textAlign: 'justify' }}>
                <div className="container">
                <h1 className="heritage-headingtwo">
                    Milestones
                </h1>
                <p className='global-p-2 text-align-center mb-5' >Maharaja Jagatjit Singh assumed full ruling powers in November 1890 and then commenced a career as a world traveler and Francophile. He received the title of Maharaja in 1911. He builtpalaces and gardens in the city of Kapurthala; his main palace, Jagatjit Palace, was modelled on the Palace of Versailles. He served as the Indian Representative to the League of Nations GeneralAssembly in Geneva in 1926, 1927 and 1929 and attended the Round Table Conference in 1931
                and was Lt Governor of the PEPSU (Patiala and East Punjab State Union) at the time of his deathin 1949, aged 76.</p>
                </div>
                
                <VerticalTimeline>
                    {timeline.map((t, i) => {
                        return (
                            <VerticalTimelineElement
                key={i}
                contentStyle={{ background: "black" }}
                contentArrowStyle={{ borderRight: "white" }}
                iconStyle={{ background: "white" }}
                icon={<span Class="icon-number">{i + 1}</span>} // Add numbers here
            >
                <div>
                    {t.image && <img src={t.image} className='img-fluid' />}
                    <p className='t-date'>{t.date}</p>
                    {t.id !== 16 ? (
                        <p className='t-content'>{t.desc}</p>
                    ) : (
                        <div className="t-content">
                            Ms. Roshini Sanah Jaiswal won the ‘Entrepreneur of the year’ Award at Indspirit 2016 (The mega Alcobev Trade Event). <br />
                            • IICE Vodka won the Gold Award for Standard Product of the Year at Indspirit 2016 (The mega Alcobev Trade Event). <br />
                            • AC Black Whisky in Packaging category won the Gold award at Indspirit 2016 (The mega Alcobev Trade Event).
                            <br />
                        </div>
                    )}
                </div>
            </VerticalTimelineElement>
                        )
                    })}
                </VerticalTimeline>
            </div>
            
            {/* <div className="milestones-section">
                <div className="container">
                    <h1 className="text-center">MILESTONES</h1>
                    <div className="timeline">
                        {timeline.map((item) => (
                            <div className="timeline-item d-flex mb-5" key={item.id}>
                                <div className="timeline-date">
                                    <h2>{item.date}</h2>
                                </div>
                                <div className={`timeline-content row ${item.image ? 'with-image'  : ''}`}>
                                    <div className="col-lg-6">
                                    {item.image && <img src={item.image} alt={item.date} className="img-fluid mb-3" />}
                                    </div>
                                    <div className="col-lg-6">
                                    <p>{item.desc}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div> */}
        </div>
    );
};

export default TimeLine;
