import React, { useEffect, useState } from "react";
import "../AcpremiumNew/AcpremiumNew.css";
import { HiArrowLongLeft, HiOutlineArrowLongRight } from "react-icons/hi2";
import { Link } from "react-router-dom";

import curtainImg from '../../../../Assets/Products/Liquor/AcpremiumOld/sectionCurtain.png';
import flavourImgs from '../../../../Assets/Products/Liquor/AcpremiumNew/bottleimgsec.png';
import flavourGroup from '../../../../Assets/Products/Liquor/AcpremiumOld/flavourGroup.png';
import bottle from '../../../../Assets/Products/Liquor/AcpremiumOld/bottles.svg';
import distik from '../../../../Assets/Products/Liquor/AcpremiumOld/distiks.svg';
import glass from '../../../../Assets/Products/Liquor/AcpremiumOld/glass.png';
import acpsectiononelogo from '../../../../Assets/Products/Liquor/AcpremiumNew/acpsectiononelogo.png';
import acpsectiontwoimg from '../../../../Assets/Products/Liquor/AcpremiumNew/acpremiumsecBottleImg.png';
import acpblack from '../../../../Assets/ArrowBottle/acBlack.svg';
import acpOld from '../../../../Assets/ArrowBottle/acpOld.svg';
import acpnewImg from '../../../../Assets/Products/Liquor/AcpremiumNew/acpnewImg.png';
import acplast from '../../../../Assets/Products/Liquor/AcpremiumNew/AcpProducts.png';
import acpsectiontwoimgs from '../../../../Assets/Products/Liquor/AcpremiumNew/acpnewImg.png';
import bendFavImg from '../../../../Assets/Products/Liquor/AcpremiumNew/bendfavimg.png';
import axios from "axios";

export const AcpremiumNew = () => {
    const [scrVideo, setScrVideo] = useState("");
    useEffect(() => {
        axios.get('https://api.jagatjit.com/api/videos')
            .then(response => {
                console.log('ressss',response.data.data);
                let data = response.data.data.find((el) => {
                    return el.name == "AC PREMIUM NEW"
                });

                setScrVideo(data.video_file)
            })
            .catch(error => {
                console.error('Error fetching users:', error);
            });
    }, []);

    return (
        <div className="acpremium-container">
        {/* //1 */}
        <div className="acpoldpagesRowDiv acpoldSecondPageSectionOneImage">
            <div className="container">
                <div className="rowdiv">
            <div className="acpsecDiv">
                <img src={acpsectiononelogo} alt="bottleImg" className="bottleImgLogo" />
                <h2 className="acpoldSecondHeading">CLASSIC WHISKEY</h2>
                <p className="global-p-2">One of India's most-loved whiskey brands with its iconic gold and deep-red bottle.</p>
            </div>
            <img src={acpsectiontwoimgs} alt="bottleImg" className="bottleImg bottleImgfirst" />
            </div>
            </div>
        </div>
    {/* //2 */}
    <div className="pagesTextDivTwo acpScondSectionTwoImage">
                {/* <img src={acplast} alt="bottleImg" className="section2BotleImg" /> */}
                <div className="pagesTextDiv">
                    <div className="pageSecondText">
                        <h1 className="sectionTwoHeading">THE ESSENCE OF</h1>
                        <h1 className="sectionTwoHeading">SOPHISTICATION</h1>
                    </div>
                    <div>
                        <p className="global-p-2 sectionTwoParagraph">Distinctive and refined in both taste and look, it is blended with pure grain and select imported Scotch malts, bringing a <span>honeyed and delightful experince</span> to its loyal patrons</p>
                    </div>
                </div>
            </div>
             {/* //3 */}
             <section className="sectionThree">
                <div className="flavourDiv">
                    <h1 className="sectionTwoHeading flavourDivHeader ">FLAVOUR PROFILE</h1>
                    <img src={flavourGroup} alt="groupBtl" className="image favBotGroupImg" />
                    <div className="profile-icon-wrap">
                        <div className="profile-icon-1 global-p-2">Elegant and Long Lasting</div>
                        <div className="profile-icon-2 global-p-2">Sweet, Floral with a touch of spices</div>
                        <div className="profile-icon-3 global-p-2">Deep Gold to the eyes</div>
                        <div className="profile-icon-4 global-p-2">Smooth, with a hint of Fruit & Spices</div>
                    </div>
                </div>        
            </section>
             {/* //4 */}
             <section className="acpsecondfourthSectionImage">
                <div className="pagesTextbetween container">
                    <h2 className="pagesTextFavorDivHeader">BEYOND LUXURY LIES LEGACY.</h2>
                    <div className="legacy-img-wrap">
                        <div className="imageText">
                            <img src={glass} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Best Enjoyed How You</p>
                                <p className="logoTextParagraph global-p-2">Like Your Scotch</p>
                            </div>
                        </div>
                        <div className="imageText">
                            <img src={bottle} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Bottled With Care By State</p>
                                <p className="logoTextParagraph global-p-2">Of the Art Bottling Facilities</p>
                            </div>
                        </div>
                        <div className="imageText">
                            <img src={distik} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Made With The Finest</p>
                                <p className="logoTextParagraph global-p-2">Indian Spirits</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
  {/* //5 */}

  <div className="video-link-redirect">
  <div className="acpvideoDiv">
                    {scrVideo && (
                        <video
                            className="videoContent"
                            width="100%"
                            height="100%"
                            // controls
                            autoPlay
                            muted
                            loop
                            playsInline
                        >
                            <source src={scrVideo} type="video/mp4" />
                            Your browser does not support the video tag.
                        </video>
                    )}
                </div>

                <div className="acpNewarrowDiv container">
                    <Link to={'/products/liquor/acpremiumold'} className="acppremiumleftArrowDiv">
                         <div className="acpNewLeftDiv">
                             <h1 className="acpNpremiumarrowHeading">AC Premium (Old)</h1>
                             <HiArrowLongLeft className="leftIconImg" />
                        </div>
                         <div className="acpNewleftSmallImg">
                             <img src={acpOld} alt="block" />
                         </div>
                     </Link>
                   <Link to={'/products/liquor/acpremiumblack'} className="acppremiumrightArrowDiv">
                        <div className="acpNewrightSmallImg" >
                             <img src={acpblack} alt="block" />
                         </div>
                        <div className="acpNewRightDiv">
                            <h1 className="acpNpremiumarrowHeading">Aristocrat Black</h1>
                           <HiOutlineArrowLongRight className="leftIconImg" />
                         </div>
                     </Link>
                 </div>  

        </div>
        
       </div>
        //     {/* //1 */}
        //     <div className=" acpNewpagesRowDiv acpSecondPageSectionOneImage">
        //         <div className="acpNewTextDiv">
        //             <h2 className="aristocratSecondHeading">THE ALL NEW</h2>
        //             <img src={acpsectiononelogo} alt="bottleImg" className="acpNewlogoImg1" />
        //             <p className="aristocratParagraph">One of India's most-loved whiskey brands with its iconic gold and deep-red bottle. Now Revamped. </p>
        //         </div>
        //         <img src={acpsectiontwoimgs} alt="bottleImg" className="acpbottleImg" />
        //     </div>
        //     {/* //2 */}
        //     <div className="acpnewpagesTextDivTwo acpNewScondSectionTwoImage">
        //         <img src={acpsectiontwoimg} alt="bottleImg" className="acpNewImg1" />
        //         <div className="acpnewpagesTextDiv">
        //             <div className="pageSecondText">
        //                 <h1 className="sectionTwoHeading">THE ESSENCE OF</h1>
        //                 <h1 className="sectionTwoHeading">SOPHISTICATION</h1>
        //             </div>
        //             <div className="sectionTwoParagraphdiv">
        //                 <p className="sectionTwoParagraph">Distinctive and refined in both taste and look, it is
        //                     blended with pure grain and select imported
        //                     Scotch malts, bringing a <span>honeyed and delightful</span>
        //                     <span> experince</span> to its loyal patrons</p>
        //             </div>
        //         </div>
        //     </div>
        //     {/* //3 */}
        //     <section className="acpNsectionThree">
        //         <div><img src={curtainImg} alt="leftCurtain" className="image" style={{height:'95vh'}}/></div>
        //         <div className="acpNflavourDiv">
        //             <h1 className="acpNflavourDivHeader">FLAVOUR PROFILE</h1>
        //             <div className="acpNewFavIconImgDiv">
        //                 <div class="profileN-icon-wrap">
        //                     <div class="profileN-icon-1">Elegant and Long Lasting</div>
        //                     <div class="profileN-icon-2">Sweet, Floral with a touch of spices</div>
        //                     <div class="profileN-icon-3">Deep Gold to the eyes</div>
        //                     <div class="profileN-icon-4">Smooth, with a hint of Fruit & Spices</div>
        //                 </div>
        //                 <picture>
        //                     <source media="(max-width:767px)" srcset={bendFavImg} />
        //                     <img src={flavourGroupimg} alt="Flowers" className="acpfavsectImg" />
        //                 </picture>

        //                 {/* <img src={flavourGroupimg} alt="groupBtl" className="acpfavsectImg" /> */}

        //             </div>
        //         </div>
        //         <div><img src={curtainImg} alt="rightCurtain" className="curtainImage image" style={{height:'95vh'}} /></div>
        //     </section>
        //     {/* //4 */}

        //     {/* <div className="acpnewHide">
        //             <h2 className="pagesTextFavorDivHeader">BEYOND LUXURY LIES LEGACY.</h2>
        //         </div> */}
        //     <section className="acpoldsecondfourthSectionImage">
        //         <div className="acpNewpagesTextbetween">
        //             <h2 className="acpNpagesTextFavorDivHeader">BEYOND LUXURY LIES LEGACY.</h2>
        //         </div>
        //         <div className="rowIconVisible">
        //             <div className="imageText">
        //                 <img src={glass} alt="bottleImg" className="acpnewlogoText" />
        //                 <div>
        //                     <p className="acpNlogoTextParagraph">Best Enjoyed How You Like Your Whiskey</p>
        //                 </div>
        //             </div>
        //             <div className="imageText">
        //                 <img src={bottle} alt="bottleImg" className="acpnewlogoText botleImg2" />
        //                 <div>
        //                     <p className="acpNlogoTextParagraph">Bottled With Care By State Of The Art Bottling Facilities</p>
        //                 </div>
        //             </div>
        //             <div className="imageText">
        //                 <img src={distik} alt="bottleImg" className="acpnewlogoText distik" />
        //                 <div>
        //                     <p className="acpNlogoTextParagraph" style={{marginLeft:'8%'}}>   Made With The Finest Indian Spirits</p>
        //                 </div>
        //             </div>
        //         </div>
        //     </section>
        //     {/* //5 */}
        //     <div>
        //         <div className="acpvideoDiv">
        //             {scrVideo && (
        //                 <video
        //                     className="videoContent"
        //                     width="100%"
        //                     height="100%"
        //                     // controls
        //                     autoPlay
        //                     muted
        //                     loop
        //                     playsInline
        //                 >
        //                     <source src={scrVideo} type="video/mp4" />
        //                     Your browser does not support the video tag.
        //                 </video>
        //             )}
        //         </div>
              
        //         <div className="acpNewarrowDiv">
        //             <Link to={'/products/liquor/acpremiumold'} className="acppremiumleftArrowDiv">
        //                 <div className="acpNewLeftDiv">
        //                     <h1 className="acpNpremiumarrowHeading">AC Premium (Old)</h1>
        //                     <HiArrowLongLeft className="leftIconImg" />
        //                 </div>
        //                 <div className="acpNewleftSmallImg">
        //                     <img src={acpOld} alt="block" />
        //                 </div>
        //             </Link>
        //             <Link to={'/products/liquor/acpremiumblack'} className="acppremiumrightArrowDiv">
        //                 <div className="acpNewrightSmallImg" >
        //                     <img src={acpblack} alt="block" />
        //                 </div>
        //                 <div className="acpNewRightDiv">
        //                     <h1 className="acpNpremiumarrowHeading">Aristocrat Black</h1>
        //                     <HiOutlineArrowLongRight className="leftIconImg" />
        //                 </div>
        //             </Link>
        //         </div>

        //     </div>
        // </div>
    )
};

