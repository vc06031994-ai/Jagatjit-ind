import React, { useEffect, useState } from "react";
import "../AcpremiumOld/AcpremiumOld.css";
import { HiArrowLongLeft, HiOutlineArrowLongRight } from "react-icons/hi2";
import { Link } from "react-router-dom";

import curtainImg from '../../../../Assets/Products/Liquor/AcpremiumOld/sectionCurtain.png';
import flavourImg from '../../../../Assets/Products/Liquor/AcpremiumOld/sectionFlavours.png';
import flavourGroup from '../../../../Assets/Products/Liquor/AcpremiumOld/flavourGroup.png';
import bottle from '../../../../Assets/Products/Liquor/AcpremiumOld/bottles.svg';
import distik from '../../../../Assets/Products/Liquor/AcpremiumOld/distiks.svg';
import glass from '../../../../Assets/Products/Liquor/AcpremiumOld/glass.png';
import acpsectiononelogo from '../../../../Assets/Products/Liquor/AcpremiumNew/acpsectiononelogo.png';
import acpsectiontwoimgs from '../../../../Assets/Products/Liquor/AcpremiumOld/sec1bottle1.png';
import acpblack from '../../../../Assets/Products/Liquor/AcpremiumNew/damnlink.svg';
import acpnewImg from '../../../../Assets/Products/Liquor/AcpremiumNew/acpnewlink.svg';
import acplast from '../../../../Assets/Products/Liquor/AcpremiumNew/acplastImg.png';
// import acpNew from '../../../../Assets/Products/Liquor/AcpremiumNew/damnlink.svg';
import royalMedol from '../../../../Assets/ArrowBottle/royalMedal.svg';
import acpNew from '../../../../Assets/ArrowBottle/acpNew.svg';
import axios from "axios";

export const AcpremiumOld = () => {
    const [scrVideo, setScrVideo] = useState("");
    useEffect(() => {
        axios.get('https://api.jagatjit.com/api/videos')
            .then(response => {
                console.log('ressss',response.data.data);
                let data = response.data.data.find((el) => {
                    return el.name == "acpremiumold"
                });

                setScrVideo(data.video_file)
            })
            .catch(error => {
                console.error('Error fetching users:', error);
            });
    }, []);
    return (
        <div className="acpremium-container">
            {/* //1 */}
            <div className="acpoldpagesRowDiv acpoldSecondPageSectionOneImage">
                <div className="container">
                    <div className="rowdiv">
                <div className="acpsecDiv">
                    <img src={acpsectiononelogo} alt="bottleImg" className="bottleImgLogo" />
                    <h2 className="acpoldSecondHeading">CLASSIC WHISKEY</h2>
                    <p className="global-p-2">One of India's most-loved whiskey brands with its iconic gold and deep-red bottle.</p>
                </div>
                <img src={acpsectiontwoimgs} alt="bottleImg" className="bottleImg bottleImgfirst" />
                </div>
                </div>
            </div>
            {/* //2 */}
            <div className="pagesTextDivTwo acpScondSectionTwoImage">
                {/* <img src={acplast} alt="bottleImg" className="section2BotleImg" /> */}
                <div className="pagesTextDiv">
                    <div className="pageSecondText">
                        <h1 className="sectionTwoHeading">THE ESSENCE OF</h1>
                        <h1 className="sectionTwoHeading">SOPHISTICATION</h1>
                    </div>
                    <div>
                        <p className="global-p-2 sectionTwoParagraph">Distinctive and refined in both taste and look, it is blended with pure grain and select imported Scotch malts, bringing a <span>honeyed and delightful experince</span> to its loyal patrons</p>
                    </div>
                </div>
            </div>
            {/* //3 */}          
            <section className="sectionThree">
                <div className="flavourDiv">
                    <h1 className="sectionTwoHeading flavourDivHeader ">FLAVOUR PROFILE</h1>
                    <img src={flavourGroup} alt="groupBtl" className="image favBotGroupImg" />
                    <div className="profile-icon-wrap">
                        <div className="profile-icon-1 global-p-2">Elegant and Long Lasting</div>
                        <div className="profile-icon-2 global-p-2">Sweet, Floral with a touch of spices</div>
                        <div className="profile-icon-3 global-p-2">Deep Gold to the eyes</div>
                        <div className="profile-icon-4 global-p-2">Smooth, with a hint of Fruit & Spices</div>
                    </div>
                </div>        
            </section>
        
            {/* //4 */}
            <section className="acpsecondfourthSectionImage">
                <div className="pagesTextbetween container">
                    <h2 className="pagesTextFavorDivHeader">BEYOND LUXURY LIES LEGACY.</h2>
                    <div className="legacy-img-wrap">
                        <div className="imageText">
                            <img src={glass} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Best Enjoyed How You</p>
                                <p className="logoTextParagraph global-p-2">Like Your Scotch</p>
                            </div>
                        </div>
                        <div className="imageText">
                            <img src={bottle} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Bottled With Care By State</p>
                                <p className="logoTextParagraph global-p-2">Of the Art Bottling Facilities</p>
                            </div>
                        </div>
                        <div className="imageText">
                            <img src={distik} alt="bottleImg" className="logoText" />
                            <div>
                                <p className="logoTextParagraph global-p-2">Made With The Finest</p>
                                <p className="logoTextParagraph global-p-2">Indian Spirits</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* //5 */}

            <div className="video-link-redirect">
                {/* <div className="acpvideoDiv">
                {scrVideo && (
                    <video
                        className="videoContent"
                        width="100%"
                        height="100%"
                        // controls
                        autoPlay
                        muted
                        loop
                        playsInline
                    >
                        <source src={scrVideo} type="video/mp4" />
                        Your browser does not support the video tag.
                    </video>
                )}
                </div> */}
                {/* <div className="acpNewarrowDiv">
                    <Link to={'/products/liquor/ACpremiumNew'} className="acppremiumleftArrowDiv">
                        <div className="acpNewLeftDiv">
                            <h1 className="acpNpremiumarrowHeading">Aristocrat Premium</h1>
                            <HiArrowLongLeft className="leftIconImg" />
                        </div>
                        <div className="acpNewleftSmallImg">
                            <img src={acpnewImg} alt="block" />
                        </div>
                    </Link>
                    <Link to={'/products/liquor/DamnGoodScotch'} className="acppremiumrightArrowDiv">
                        <div className="acpNewrightSmallImg" >
                            <img src={acpblack} alt="block" />
                        </div>
                        <div className="acpNewRightDiv">
                            <h1 className="acpNpremiumarrowHeading">Damn Good Scotch</h1>
                            <HiOutlineArrowLongRight className="leftIconImg" />
                        </div>
                    </Link>
                </div> */}
                <div className="acpvideoDiv">
                    {scrVideo && (
                        <video
                            className="videoContent"
                            width="100%"
                            height="100%"
                            // controls
                            autoPlay
                            muted
                            loop
                            playsInline
                        >
                            <source src={scrVideo} type="video/mp4" />
                            Your browser does not support the video tag.
                        </video>
                    )}
                </div>
                               <div className="acpNewarrowDiv container">
                    <Link to={'/products/liquor/royalmedallion'} className="acppremiumleftArrowDiv">
                        <div className="acpNewLeftDiv">
                            <h1 className="acpNpremiumarrowHeading">Royal Medallion</h1>
                            <HiArrowLongLeft className="leftIconImg" />
                        </div>
                        <div className="acpNewleftSmallImg">
                            <img src={royalMedol} alt="block" /> 
                        </div>
                    </Link>
                    <Link to={'/products/liquor/acpremium'} className="acppremiumrightArrowDiv">
                        <div className="acpNewrightSmallImg" >
                            <img src={acpNew} alt="block" />
                        </div>
                        <div className="acpNewRightDiv">
                            <h1 className="acpNpremiumarrowHeading">AC Black</h1>
                            <HiOutlineArrowLongRight className="leftIconImg" />
                        </div>
                    </Link>
                </div>  
            </div>
        </div>
    )
};

